export const MetaConsts = {
  locale: 'en_US',
  siteName: 'DT&amp;T Money Transfer',
  title: 'Send Money Online',
  url: 'window.location.origin',
  type: 'website',
  image: `${window.location.origin}/assets/images/social-share-logo.png`,
  width: '200',
  height: '200',
  description: 'o download to your mobile, select your device platform below Reasons to choose DT&amp;T Our aim is to provide a simple, courteous, cost-effective and excellent service to our clients through technology and traditional phone base services with competitive and transparent pricing. Low Cost Our fees a',
};
