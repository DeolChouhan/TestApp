import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UserConsts } from '../../user/configs/constants';
import { eUserType, LoginStatusEnum } from '../../user/enums';
import { StatePersistService } from '../services/state-persist.service';

@Injectable({
  providedIn: 'root'
})
export class SelfVerificationGuard implements CanActivate {

  private securityQuestionUrl = 'user/security-questions/add';
  private firstStepUrl = 'user/self-verification/first-step';
  private secondStepUrl = 'user/self-verification/second-step';
  private thirdStepUrl = 'user/self-verification/third-step';

  constructor(
    private router: Router,
    private stateService: StatePersistService
  ) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // const currentUser = this.stateService.getSession(UserConsts.CURRENT_USER);
    const currentUser = this.stateService.getLocalStorage(UserConsts.CURRENT_USER);
    const authorizedUser = currentUser?.authorizedUser;

    if (authorizedUser.userTypeId === eUserType.Admin) {
      this.router.navigate(['/admin/dashboard']);
    }

    if (currentUser?.status === LoginStatusEnum.AddSecurityQuestions && state.url.indexOf(this.securityQuestionUrl) < 0) {
      this.router.navigate([`/${this.securityQuestionUrl}`]); return false;
    } else if (authorizedUser?.isFirstStepDone === false && currentUser?.status !== LoginStatusEnum.AddSecurityQuestions) {
      if (state.url.indexOf(this.firstStepUrl) < 0) {
        this.router.navigate([`${this.firstStepUrl}`]); return false;
      }
    } else if (authorizedUser?.isSecondStepDone === false && currentUser?.status !== LoginStatusEnum.AddSecurityQuestions) {
      if (state.url.indexOf(this.secondStepUrl) < 0) {
        this.router.navigate([`${this.secondStepUrl}`]); return false;
      }
    } else if (authorizedUser?.isThirdStepDone === false && currentUser?.status !== LoginStatusEnum.AddSecurityQuestions) {
      if (state.url.indexOf(this.thirdStepUrl) < 0) {
        this.router.navigate([`${this.thirdStepUrl}`]); return false;
      }
    }
    if (this.isValidUrl(state.url, authorizedUser, currentUser?.status)) { this.router.navigate([`/`]); return false; }
    return true;
  }

  private isValidUrl(url: string, authorizedUser: any, status: any): boolean {
    return (status !== LoginStatusEnum.AddSecurityQuestions && url.indexOf(this.securityQuestionUrl) >= 0)
      || (authorizedUser?.isFirstStepDone && url.indexOf(this.firstStepUrl) >= 0)
      || (authorizedUser?.isSecondStepDone && url.indexOf(this.secondStepUrl) >= 0)
      || (authorizedUser?.isThirdStepDone && url.indexOf(this.thirdStepUrl) >= 0);
  }
}
