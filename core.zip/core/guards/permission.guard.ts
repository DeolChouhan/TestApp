import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthorizationService } from '../services/authorization.service';

@Injectable({
  providedIn: 'root'
})
export class PermissionGuard implements CanActivate {

  constructor(
    protected router: Router,
    public authorizationService: AuthorizationService
  ) { }

  canActivate(route: ActivatedRouteSnapshot): Promise<boolean> | boolean {
    return this.hasRequiredPermission(route.data['role'], route.data['permissionName']);
  }

  protected hasRequiredPermission(role, permissionName): boolean {
    const hasAccess = this.authorizationService.hasPermission(role, permissionName);
    if (!hasAccess) { this.router.navigate(['/admin/dashboard']); }
    return hasAccess;
  }
}
