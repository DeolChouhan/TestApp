import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UserConsts } from '../../user/configs/constants';
import { LoginStatusEnum, UserStatusEnum } from '../../user/enums';
import { StatePersistService } from '../services/state-persist.service';

@Injectable({
  providedIn: 'root'
})
export class SelfVerifiedGuard implements CanActivate {

  private verificationCompletedUrl = 'user/self-verification/completed';

  constructor(
    private router: Router,
    private stateService: StatePersistService
  ) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // const currentUser = this.stateService.getSession(UserConsts.CURRENT_USER);
    const currentUser = this.stateService.getLocalStorage(UserConsts.CURRENT_USER);

    if (state.url.indexOf(this.verificationCompletedUrl) !== -1) {
      return true;
    }

    if (currentUser?.authorizedUser?.userStatusId == UserStatusEnum.SelfVerified) {
      this.router.navigate([this.verificationCompletedUrl]); return false;
    }
    return true;
  }
}
