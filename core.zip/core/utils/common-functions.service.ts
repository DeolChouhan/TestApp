import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { LocationStrategy } from '@angular/common';
import { Router } from '@angular/router';
import { SecureService } from '../services/secure.service';

@Injectable({
  providedIn: 'root'
})
export class CommonFunctionsService {

  constructor(
    private router: Router,
    private domSanitizationService: DomSanitizer,
    private locationStrategy: LocationStrategy,
    private secureService: SecureService,
  ) { }

  public preventBackButton(): void {
    history.pushState(null, null, location.href);
    this.locationStrategy.onPopState(() => {
      history.pushState(null, null, location.href);
    });
  }

  public get detectMobile(): boolean {
    const toMatch = [/Android/i, /webOS/i, /iPhone/i, /iPad/i, /iPod/i, /BlackBerry/i, /Windows Phone/i];

    return toMatch.some((toMatchItem) => {
      return navigator.userAgent.match(toMatchItem);
    });
  }

  public inputNumberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) { return false; }
    return true;
  }

  public redirectToDttcl(): void {
    // window.location.href = environment.dttclSiteUrl;
    window.open(environment.dttclSiteUrl, '_blank');
  }

  public imagebase64toUrl(base64String: any) {
    if (!base64String) { return ''; }
    if (base64String instanceof Object) { return base64String; }
    const type = base64String.charAt(0).toLowerCase() === 'p' ? 'svg+xml' : 'png';
    return this.domSanitizationService.bypassSecurityTrustUrl(`data:image/${type};base64,` + base64String);
  }

  public isBase64(str) {
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return false;
    }
  }

  removeAllWhiteSpaces(str: string) {
    return str.replace(/ /g, '');
  }

  public enumToArrayObject(emun, isNumericValue = false): string[] {
    const enumToArray = [];
    const objectEnum = Object.keys(emun);
    const values = objectEnum.slice(0, objectEnum.length / 2);
    const keys = objectEnum.slice(objectEnum.length / 2);
    for (let i = 0; i < objectEnum.length / 2; i++) {
      enumToArray.push({ key: keys[i], value: isNumericValue ? +values[i] : isNumericValue });
    }
    return enumToArray;
  }

  public base64ToTrustedUrl(base64String: any): any {
    if (!base64String) { return ''; }
    return this.domSanitizationService.bypassSecurityTrustUrl(base64String);
  }

  public getQueryParams(page, size): any {
    const offset = (page - 1) * size;
    return `?skip=${offset}&take=${size}`;
  }

  public pagination(page, size, allRecords): any {
    const start = (page - 1) * size;
    const end = start + size;
    return allRecords.slice(start, end);
  }

  public redirectWithEncryptedParams(url, ...val): void {
    const path = this.formatString(url, ...val);
    this.router.navigate([path]);
  }

  private formatString(str: string, ...val: string[]): string {
    for (let index = 0; index < val.length; index++) {
      str = str.replace(`{${index}}`, this.secureService.encrypt(val[index]));
    }
    return str;
  }

  public copyTextToClipBoard(value: string): void {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = value;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }
}
