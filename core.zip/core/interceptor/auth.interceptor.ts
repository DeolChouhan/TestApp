import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpResponse, HttpRequest, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { StatePersistService } from '../services/state-persist.service';
import { UserConsts } from '../../user/configs/constants';
import { WalletConsts } from '../../wallet/configs/constants';
import { SharedConsts } from '../../shared/constants';


@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(
        private router: Router,
        private stateService: StatePersistService
    ) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        let request: any;
        // const currentUser = this.stateService.getSession(UserConsts.CURRENT_USER);
        const currentUser = this.stateService.getLocalStorage(UserConsts.CURRENT_USER);
        const isJsonIpUrl = req.url == WalletConsts.JSON_IP_URL;
        if (isJsonIpUrl) { request = req; }
        if (!isJsonIpUrl && !req.headers.has('Content-Type')) {
            request = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
        }
        if (!isJsonIpUrl && currentUser) {
            request = req.clone({ setHeaders: { Authorization: `bearer ${currentUser.token}` } });
        }

        if (req.headers.has(SharedConsts.USER_TEMP_TOKEN)) {
            const token = req.headers['headers'].get(SharedConsts.USER_TEMP_TOKEN);
            request = req.clone({ setHeaders: { Authorization: `bearer ${token}` } });
        }

        return next.handle(request).pipe(tap((evt) => {
        }, (err: any) => {
            if (err instanceof HttpErrorResponse) { }
        }));
    }
}
