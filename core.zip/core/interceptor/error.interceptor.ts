import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserConsts } from '../../user/configs/constants';
import { AlertService } from '../services/alert.service';
import { StatePersistService } from '../services/state-persist.service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private router: Router,
    private alertService: AlertService,
    private stateService: StatePersistService
  ) { }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((err) => {
        if (err.status === 500) {
          this.alertService.error(UserConsts.SOMETHING_WENT_WRONG_ERROR);
          return throwError(err);
        }
        if (err.status === 404) {
          return throwError(err);
        }
        if (err.status === 403) {
          this.alertService.error('You are not authorized to view this page');
          return throwError(err);
        }
        if (
          err.status === 401 ||
          (err?.status === 400 && err?.error?.status == 5)
        ) {
          // auto logout if 401 response returned from api
          if (err?.error?.status) {
            this.alertService.error(err?.error?.message);
          }
          // this.stateService.removeSession(UserConsts.CURRENT_USER);
          this.stateService.removeLocalStorage(UserConsts.CURRENT_USER);
          this.router.navigate(['/login']);
          return throwError(err);
        }
        let error: any;
        try {
          if (err.error instanceof Array) {
            err.error.forEach((element) => {
              this.alertService.error(element.Message);
            });
          } else if (err.status === 400) {
            const keys = Object.keys(err?.error?.errors);
            keys.forEach((key) => {
              this.alertService.error(err?.error?.errors[key].toString());
            });
          } else {
            error =
              err.status === 0
                ? UserConsts.SOMETHING_WENT_WRONG_ERROR
                : err.statusText;
            this.alertService.error(error);
          }
        } catch (e) {
          error = err.statusText;
          this.alertService.error(error);
        }
        return throwError(err);
      })
    );
  }
}
