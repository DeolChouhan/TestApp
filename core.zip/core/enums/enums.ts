export enum DeviceTypeEnum {
  iOS = 1,
  Android = 2,
  Web = 3,
}

export enum eCustomerType {
  CorporateCustomer = 1,
  PrivateCustomer = 2,
}

export enum eChargeType {
  Percent = 1,
  Amount = 2,
}

export enum WalletMoneyOptionsEnum {
  LoadMoney = 1,
  SendMoney = 2,
  ConvertMoney = 3,
  WithdrawMoney = 4,
}

export enum eWalletDepositType {
  BankTransfer = 1,
  CardPayment = 2,
  CreditCard = 3,
  DebitCard = 4,
}

export enum eMarginType {
  Amount = 1,
  Percentage = 2,
}

export enum eWalletChargeType {
  FundWalletByBankTransfer = 1,
  FundWalletByCard = 2,
  SendMoneyToDTTFriend = 3,
  WithdrawFromWallet = 4,
}

export enum eTypeOfPayout {
  'Cash Payout' = 1,
  'Bank Transfer -Regular' = 2,
  'Bank Transfer - Swift' = 3,
  'Airtime' = 4,
  'Mobile Wallet' = 5,
}

export enum eAdminStatus {
  'Inactive' = 0,
  'Active' = 1,
}

export enum eGender {
  Male = 1,
  Female = 2,
  Other = 3,
}

export enum eMarketingContactType {
  Email = 1,
  Phone = 2,
  TextMessage = 3,
  Post = 4,
  PushNotification = 5,
  VisibleToOthers = 6,
}

export enum eOrderStatus {
  New = 1, //before cc
  LegalHold = 2,
  Pending = 3,
  Submitted = 4, //after cc
  Completed = 5, //after cc paid
  Failed = 6, //cc failed
  Authorised = 7, //After LegalHold, compliance will change it to Authorised
  Cancelled = 8,
}

export enum eWalletFundStatus {
  GeneratePaymentUrl = 1,
  Attempted = 2,
  PaymentUrlFailed = 3,
  New = 4,
  PaymentFailed = 5,
  LegalHold = 6,
  Approve = 7,
  Completed = 8,
  Cancel = 9,
  Returned = 10,
}

export enum eAdjustmentType {
  CR = 1,
  DR = 2,
}

export enum ePOIStatus {
  IDVerified = 1,
  IDNotVerified = 2,
  IDExpired = 3,
}

export enum eAnnualSalary {
  '1	- 10,000' = 1,
  '10,001 - 20,000' = 2,
  '20,001 - 30,000' = 3,
  '30,001 - 40,000' = 4,
  '40,001 - 50,000' = 5,
  '50,001 +' = 6,
  'Not Known' = 7,
}
export enum eEmploymentType {
  'Full time' = 1,
  'Part time' = 2,
  'Unemployed' = 3,
  'Self employed' = 4,
  'Student' = 5,
  'Pensioner' = 6,
}
export enum eCorrespondentType {
  CurrencyCloud = 1,
  DTTNGN = 2,
}

export enum eWalletDepositTypeForSearch {
  'Bank Transfer' = 1,
  'Card Payment' = 2,
}

export enum eConversionMarginStatus {
  New = 1,
  Completed = 2,
  Cancel = 3,
}

export enum eAdjustmentStatus {
  New = 1,
  Completed = 2,
  Cancel = 3,
}

export enum eWalletFundStatusForSearch {
  'Attempted' = 2,
  'New' = 4,
  'Payment Failed' = 5,
  'Legal Hold' = 6,
  'Approve' = 7,
  'Completed' = 8,
  'Cancel' = 9,
  'Returned' = 10,
}
