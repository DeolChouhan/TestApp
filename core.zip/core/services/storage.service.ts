import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../environments/environment';

const SecureStorage = require('secure-web-storage');

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor() { }

  public secureLocalStorage = new SecureStorage(localStorage, {

    hash: function hash(key): any {
      key = CryptoJS.SHA256(key, environment.secretKey);
      return key.toString();
    },

    // Encrypt the localstorage data
    encrypt: function encrypt(data): any {
      data = CryptoJS.AES.encrypt(data, environment.secretKey);
      data = data.toString();
      return data;
    },
    // Decrypt the encrypted data
    decrypt: function decrypt(data): any {
      data = CryptoJS.AES.decrypt(data, environment.secretKey);
      data = data.toString(CryptoJS.enc.Utf8);
      return data;
    }
  });

  public secureSessonStorage = new SecureStorage(sessionStorage, {

    hash: function hash(key): any {
      key = CryptoJS.SHA256(key, environment.secretKey);
      return key.toString();
    },
    // Encrypt the Session storage data
    encrypt: function encrypt(data): any {
      data = CryptoJS.AES.encrypt(data, environment.secretKey);
      data = data.toString();
      return data;
    },
    // Decrypt the encrypted data
    decrypt: function decrypt(data): any {
      data = CryptoJS.AES.decrypt(data, environment.secretKey);
      data = data.toString(CryptoJS.enc.Utf8);
      return data;
    }
  });
}
