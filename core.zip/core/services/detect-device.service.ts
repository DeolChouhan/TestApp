import { Injectable } from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DeviceTypeEnum } from '../enums/enums';

@Injectable({
  providedIn: 'root'
})
export class DetectDeviceService {

  public deviceInfo: any;
  private deviceTypeEnum: DeviceTypeEnum;

  constructor(
    private deviceService: DeviceDetectorService,
  ) { }

  public getDeviceInfo(): any {
    if (this.deviceInfo) { return this.deviceInfo; }
    this.deviceInfo = this.deviceService.getDeviceInfo();
    return this.deviceInfo;
  }

  public get isMobile(): boolean {
    return this.deviceService.isMobile();
  }

  public get isTablet(): boolean {
    return this.deviceService.isTablet();
  }

  public get isDesktop(): boolean {
    return this.deviceService.isDesktop();
  }

  public get deviceType(): number {
    const deviceInfo = this.getDeviceInfo();
    if (deviceInfo.os === DeviceTypeEnum[DeviceTypeEnum.iOS]) {
      return DeviceTypeEnum.iOS;
    } else if (deviceInfo.os === DeviceTypeEnum[DeviceTypeEnum.Android]) {
      return DeviceTypeEnum.Android;
    } else {
      return DeviceTypeEnum.Web;
    }

  }


}
