import { Injectable } from '@angular/core';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class StatePersistService {

  constructor(
    private storageService: StorageService
  ) { }

  public setSession(token: string, data: any): void {
    this.storageService.secureSessonStorage.setItem(token, data);
    // sessionStorage.setItem(token, JSON.stringify(data));
  }

  public getSession(token: string): any {
    return this.storageService.secureSessonStorage.getItem(token);
    // return JSON.parse(sessionStorage.getItem(token));
  }

  public removeSession(token: string): void {
    this.storageService.secureSessonStorage.removeItem(token);
    // sessionStorage.removeItem(token);
  }

  public setLocalStorage(token: string, data: any): void {
    this.storageService.secureLocalStorage.setItem(token, data);
    // localStorage.setItem(token, JSON.stringify(data));
  }

  public getLocalStorage(token: string): any {
    return this.storageService.secureLocalStorage.getItem(token);
    // return JSON.parse(localStorage.getItem(token));
  }

  public removeLocalStorage(token: string): void {
    this.storageService.secureLocalStorage.removeItem(token);
    // localStorage.removeItem(token);
  }
}
