import { Injectable } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { MetaConsts } from '../configs/meta-constants';

@Injectable({
  providedIn: 'root'
})
export class SocialMetaService {

  constructor(
    private readonly metaService: Meta,
    private readonly titleService: Title
  ) { }

  public setFacebookTag(): void {
    this.metaService.updateTag({ name: 'og:locale', content: MetaConsts.locale });
    this.metaService.updateTag({ name: 'og:site_name', content: MetaConsts.siteName });
    this.metaService.updateTag({ property: 'og:title', content: MetaConsts.title });
    this.metaService.updateTag({ property: 'og:url', content: MetaConsts.url });
    this.metaService.updateTag({ name: 'og:type', content: MetaConsts.type });
    this.metaService.updateTag({ name: 'og:image', content: MetaConsts.image });
    this.metaService.updateTag({ name: 'og:image:width', content: MetaConsts.width });
    this.metaService.updateTag({ name: 'og:image:height', content: MetaConsts.height });
    this.metaService.updateTag({ name: 'og:description', content: MetaConsts.description });
  }

  public removeFacebookTag(): void {
    this.metaService.removeTag(`name='og:locale'`);
    this.metaService.removeTag(`name='og:site_name'`);
    this.metaService.removeTag(`property='og:title'`);
    this.metaService.removeTag(`property='og:url'`);
    this.metaService.removeTag(`name='og:type'`);
    this.metaService.removeTag(`name='og:image'`);
    this.metaService.removeTag(`name='og:width'`);
    this.metaService.removeTag(`name='og:height'`);
    this.metaService.removeTag(`name='og:description'`);
  }

  public setTwiterTag(): void {
    this.metaService.updateTag({ name: 'twitter:title', content: MetaConsts.title });
    this.metaService.updateTag({ name: 'twitter:url', content: MetaConsts.url });
    this.metaService.updateTag({ property: 'twitter:description', content: MetaConsts.description });
    this.metaService.updateTag({ property: 'twitter:image', content: MetaConsts.image });
    this.metaService.updateTag({ name: 'twitter:height', content: MetaConsts.height });
    this.metaService.updateTag({ name: 'twitter:width', content: MetaConsts.width });
  }

  public removeTwitterTag(): void {
    this.metaService.removeTag(`name='twitter:title'`);
    this.metaService.removeTag(`name='twitter:url'`);
    this.metaService.removeTag(`property='twitter:description'`);
    this.metaService.removeTag(`property='twitter:image'`);
    this.metaService.removeTag(`property='twitter:height'`);
    this.metaService.removeTag(`property='twitter:width'`);
  }
}
