import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../environments/environment';

const SecureStorage = require('secure-web-storage');

@Injectable({
  providedIn: 'root'
})
export class SecureService {

  constructor() { }

  // Encrypt data
  public encrypt(data): any {
    // return encodeURIComponent(btoa(`${data}`));
    // data = CryptoJS.AES.encrypt(`${data}`, environment.secretKey);
    // data = encodeURIComponent(data.toString());
    // return data;
    const b64 = CryptoJS.AES.encrypt(`${data}`, environment.secretKey);
    const e64 = CryptoJS.enc.Base64.parse(b64.toString());
    const eHex = e64.toString(CryptoJS.enc.Hex);
    return eHex;
  }

  // Decrypt the encrypted data
  public decrypt(data): any {
    // data = CryptoJS.AES.decrypt(decodeURIComponent(data), environment.secretKey);
    // data = data.toString(CryptoJS.enc.Utf8);
    // return data;
    const reb64 = CryptoJS.enc.Hex.parse(data);
    const bytes = reb64.toString(CryptoJS.enc.Base64);
    const decrypt = CryptoJS.AES.decrypt(bytes, environment.secretKey);
    const plain = decrypt.toString(CryptoJS.enc.Utf8);
    return plain;
  }
}
