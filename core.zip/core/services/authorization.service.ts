import { Injectable } from '@angular/core';
import { StatePersistService } from './state-persist.service';
import { UserConsts } from '../../user/configs/constants';

@Injectable({
  providedIn: 'root',
})
export class AuthorizationService {
  public permissions: any = [];

  constructor(private stateService: StatePersistService) {}

  public hasPermission(role, permissionId): boolean {
    this.getPermissionData();
    var user = this.stateService.getLocalStorage(
      UserConsts.CURRENT_USER
    )?.authorizedUser;

    if (user.isSuperAdmin == true) {
      return true;
    }
    const permission =
      this.permissions.find((d) => d.permissionId == permissionId) || {};
    return permission[role] || false;
  }

  private getPermissionData(): void {
    // if (Object.keys(this.permissions).length > 0) {
    //   return;
    // }
    // const currentUser = this.stateService.getSession(UserConsts.CURRENT_USER)?.authorizedUser;
    const currentUser = this.stateService.getLocalStorage(
      UserConsts.CURRENT_USER
    )?.authorizedUser;
    this.permissions = currentUser?.permissions || [];
  }
}
