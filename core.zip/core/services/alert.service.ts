import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { UserMessage } from '../../user/configs/messages';

@Injectable({
  providedIn: 'root'
})
export class AlertService {

  constructor(
    private toastrService: ToastrService,
  ) { }

  public success(message: string, title = ''): void {
    if (!message) { return; }
    this.toastrService.success(message, title, {
      timeOut: 4000,
      closeButton: true,
    });
  }

  public error(message: string, title = ''): void {
    if (!message) { return; }
    this.toastrService.error(message, title, {
      timeOut: 8000,
      closeButton: true,
      // positionClass: 'toast-bottom-center',
    });
  }

  public warning(message: string, title = ''): void {
    this.toastrService.warning(message, title);
  }

  public showError(response: any): void {
    const message = response.status === 500 ? `${UserMessage.INTERNAL_SERVER_ERROR} ${response?.data}`
      : response.message;
    this.error(message);
  }
}
